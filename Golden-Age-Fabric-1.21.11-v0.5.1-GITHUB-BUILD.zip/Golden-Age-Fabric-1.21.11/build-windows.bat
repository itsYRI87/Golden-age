@echo off
setlocal
echo Building Golden Age for Minecraft 1.21.11...
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Install Gradle 8.14 or newer and ensure gradle is on PATH.
  exit /b 1
)
gradle --no-daemon clean build
if errorlevel 1 exit /b %errorlevel%
echo Build complete. Check build\libs for the mod JAR.
endlocal
