GOLDEN AGE — BETA-INSPIRED RESOURCE PACK
Minecraft Java Edition 1.21.11 • pack format 75

This is an original fan-made visual interpretation inspired by the earthy look of Minecraft Beta 1.6.6. It is not an exact extraction or copy of Mojang assets.

Included:
- Muted olive grass and foliage biome colormaps (not the bright Alpha palette)
- Blue-green water colormap
- Original 16×16 pixel-art replacements for selected terrain and oak textures
- Original animated still and flowing water textures

Install: Options → Resource Packs → Open Pack Folder, then put this folder in the resourcepacks directory and enable it.

Some blocks and visual systems retain modern vanilla textures. This pack does not change music, entity sounds, GUI, fog, terrain generation, or survival rules. Use with the Golden Age Fabric mod for the mod's supported mechanics. Back up worlds before testing development builds.
