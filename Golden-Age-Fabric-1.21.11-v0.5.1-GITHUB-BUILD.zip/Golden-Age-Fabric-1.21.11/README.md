# Golden Age 0.5.0 — Fabric 1.21.11 development build

Golden Age is a work-in-progress Beta 1.6.6-inspired project. It aims to retain modern Minecraft content while restoring selected classic-era mechanics and atmosphere. Java 21, Fabric Loader 0.18.1+, and Fabric API for 1.21.11 are required.

## Included in this source build

- Fabric mod metadata and Java source for classic survival settings.
- Config file at `config/goldenage.properties`: `classicSurvival`, `hideHungerHud`, and `disableSprinting` (all default to true).
- Eleven data-driven classic biome definitions and the `#goldenage:beta_classic` biome tag.
- A standalone resource pack with original muted Beta-inspired grass/foliage/water colormaps, selected original 16×16 terrain/oak textures, and animated water textures.

## Important limitations

- This archive is source code, not a compiled JAR. It has not been compiled or tested in Minecraft in this environment.
- The eleven biome JSON definitions are not yet wired into natural Overworld biome selection. Their feature lists are still empty, so they are not a complete world-generation implementation.
- Classic sounds/music, old GUI, classic terrain shaping, fog/lighting/weather changes, and Beta food-heals-health behavior are not implemented.
- The mixin targets must be verified by an actual Gradle build and in-game launch.

## Build on GitHub Actions

1. Upload this project folder's contents to a GitHub repository (the `build.gradle` file must be at the repository root).
2. Push to the `main` or `master` branch, or open **Actions → Build Golden Age → Run workflow**.
3. Wait for the workflow to finish. Open its successful run and download the `golden-age-1.21.11-build` artifact.
4. Inside the artifact, use `golden-age-0.5.0.jar` (not the `-sources.jar`) in your Minecraft `mods` folder. Install Fabric Loader 1.21.11 and matching Fabric API too.

The workflow uses Java 21 and Gradle 8.14.3. A successful build only confirms compilation; it does not replace an in-game test.

## Build on Windows

1. Install a JDK 21 and Gradle 8.14 or newer.
2. Open PowerShell in this folder.
3. Run `gradle build` (or use IntelliJ IDEA's Gradle tool window).
4. If successful, copy the non-`-sources` JAR from `build/libs/` into `.minecraft/mods`. Install Fabric Loader 1.21.11 and matching Fabric API too.

## Install the resource pack

Open Minecraft → Options → Resource Packs → Open Pack Folder. Copy `resource-pack/Golden-Age-Beta-Palette` into that folder and enable it. The pack is built for Java 1.21.11 (resource pack format 75).

Test in a disposable new world and keep backups. Report the first Gradle error and its full `Caused by` section if the build fails.
