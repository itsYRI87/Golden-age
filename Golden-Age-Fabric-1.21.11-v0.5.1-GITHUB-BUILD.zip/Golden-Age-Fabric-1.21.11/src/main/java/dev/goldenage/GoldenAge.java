package dev.goldenage;

import dev.goldenage.config.GoldenAgeConfig;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class GoldenAge implements ModInitializer {
    public static final String MOD_ID = "goldenage";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        GoldenAgeConfig.load();
        LOGGER.info("Golden Age {} initialized. Classic survival: {}, sprinting disabled: {}",
                "0.5.0", GoldenAgeConfig.CLASSIC_SURVIVAL,
                GoldenAgeConfig.DISABLE_SPRINTING);
    }
}
