package dev.goldenage.config;

import dev.goldenage.GoldenAge;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Small dependency-free config. Values are re-read on startup. */
public final class GoldenAgeConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("goldenage.properties");

    public static boolean CLASSIC_SURVIVAL = true;
    public static boolean HIDE_HUNGER_HUD = true;
    public static boolean DISABLE_SPRINTING = true;

    private GoldenAgeConfig() {}

    public static void load() {
        Properties p = new Properties();
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE)) {
                p.load(reader);
            } catch (IOException e) {
                GoldenAge.LOGGER.error("Could not read Golden Age config", e);
            }
        }
        CLASSIC_SURVIVAL = Boolean.parseBoolean(p.getProperty("classicSurvival", "true"));
        HIDE_HUNGER_HUD = Boolean.parseBoolean(p.getProperty("hideHungerHud", "true"));
        DISABLE_SPRINTING = Boolean.parseBoolean(p.getProperty("disableSprinting", "true"));
        saveDefaults();
    }

    private static void saveDefaults() {
        Properties p = new Properties();
        p.setProperty("classicSurvival", Boolean.toString(CLASSIC_SURVIVAL));
        p.setProperty("hideHungerHud", Boolean.toString(HIDE_HUNGER_HUD));
        p.setProperty("disableSprinting", Boolean.toString(DISABLE_SPRINTING));
        p.setProperty("#", "Golden Age options. Restart Minecraft after editing.");
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                p.store(writer, "Golden Age configuration");
            }
        } catch (IOException e) {
            GoldenAge.LOGGER.error("Could not write Golden Age config", e);
        }
    }
}
