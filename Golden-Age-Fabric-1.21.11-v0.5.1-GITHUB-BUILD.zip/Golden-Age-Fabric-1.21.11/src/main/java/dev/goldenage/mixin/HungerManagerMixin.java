package dev.goldenage.mixin;

import dev.goldenage.config.GoldenAgeConfig;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HungerManager.class)
public abstract class HungerManagerMixin {
    @Shadow private int foodLevel;
    @Shadow private float saturationLevel;
    @Shadow private float exhaustion;

    @Inject(method = "update", at = @At("HEAD"), cancellable = true)
    private void goldenage$removeHungerDrain(ServerPlayerEntity player, CallbackInfo ci) {
        if (!GoldenAgeConfig.CLASSIC_SURVIVAL) return;
        foodLevel = 20;
        saturationLevel = 20.0F;
        exhaustion = 0.0F;
        ci.cancel();
    }
}
