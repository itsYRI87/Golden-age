package dev.goldenage.mixin;

import dev.goldenage.config.GoldenAgeConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderFood", at = @At("HEAD"), cancellable = true)
    private void goldenage$hideHungerBar(DrawContext context, PlayerEntity player, int top, int right, CallbackInfo ci) {
        if (GoldenAgeConfig.HIDE_HUNGER_HUD) ci.cancel();
    }
}
