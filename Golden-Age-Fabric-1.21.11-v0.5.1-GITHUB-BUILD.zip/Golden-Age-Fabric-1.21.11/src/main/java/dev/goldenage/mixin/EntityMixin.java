package dev.goldenage.mixin;

import dev.goldenage.config.GoldenAgeConfig;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "setSprinting", at = @At("HEAD"), cancellable = true)
    private void goldenage$blockPlayerSprint(boolean sprinting, CallbackInfo ci) {
        if (sprinting && GoldenAgeConfig.DISABLE_SPRINTING && (Object) this instanceof PlayerEntity) {
            ci.cancel();
        }
    }
}
